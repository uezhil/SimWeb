import { Component, OnInit } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { RouterOutlet,RouterLink } from '@angular/router';
import { IMovie } from './movie.model';
import { MovieService } from './movie.service';
import { MovieRatingComponent } from "../shared/movie-rating/movie-rating.component";

@Component({
  selector: 'app-movies',
  imports: [FormsModule, CommonModule,RouterLink,MovieRatingComponent],
  templateUrl: './movies.component.html',
  styleUrl: './movies.component.css'
})
export class MoviesComponent implements OnInit{
  
  //props
  
  // movieID:number = 1001;
  // movieName:string = "Inception";
  // movieColl:number = 1000000;
  // movieImg="inception.jpg";
  _searchTerm:string = "";
  searchedMovies:IMovie[];
  imgHeight = 100;
  imgWidth = 200;
  imgBorder = 10;
  movies:IMovie[]=[];
  title='Emovies';
  //Getter/Setter
  get searchTerm():string{
    return this._searchTerm;
  }
  set searchTerm(value:string){
      this._searchTerm = value;
      this.searchedMovies = this.searchTerm ?
      this.performSearch(this._searchTerm):this.movies;
  }
  //3.Using the Service with Dependency Injection 
  //Constructor DI
 
  constructor(private _movservice:MovieService){
 
  this.movies = this._movservice.getMovies() ;
    this.searchedMovies=this.movies;
    console.log("Here we will invoke DI for service");
}
  ngOnInit(): void {
  console.log("At the init phase now");
  
      }
performSearch(searchby:string):IMovie[]{
  searchby=searchby.toLocaleLowerCase();
  return this.movies.filter((movie:IMovie)=>
  movie.movieName.toLocaleLowerCase().indexOf(searchby)!==-1);
  }

check():void{
  console.log("Searching for : "+ this.searchTerm );
  
}

onRatingClicked(rate:string):void{
    this.title = 'Top Movies ' + rate;
  }

}





