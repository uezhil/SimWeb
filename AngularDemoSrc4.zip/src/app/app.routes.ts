import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MoviesComponent } from './movies/movies.component';
import { MovieDetailComponent } from './movie-detail/movie-detail.component';
import { UserComponent } from './user/user.component';
import { CustomerComponent } from './customer/customer.component';
import { MovieEditComponent } from './movie-edit/movie-edit.component';


//1.Route Table configuration with paths
export const routes: Routes = [
{path:'home',component:HomeComponent},
{path:'movies',component:MoviesComponent},
{path:'movies/:id',component:MovieDetailComponent},
{path:'movies/:id/edit',component:MovieEditComponent},
{path:'user',component:UserComponent},
{path:'customer',component:CustomerComponent},
{path:'',redirectTo:'home',pathMatch:'full'},
{path:'**',component:HomeComponent,pathMatch:'full'},

];
