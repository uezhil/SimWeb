import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IMovie } from '../movies/movie.model';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../movies/movie.service';

@Component({
  selector: 'app-movie-edit',
  imports: [FormsModule],
  templateUrl: './movie-edit.component.html',
  styleUrl: './movie-edit.component.css'
})
export class MovieEditComponent {

   id:number|undefined;
  movie:IMovie|undefined;
  

  //DI
  constructor(
    private router:Router,
    private aroute:ActivatedRoute,
    private movService:MovieService
  ){}
  
  ngOnInit():void{

    this.id = Number(this.aroute.snapshot.paramMap.get('id'));
    console.log(this.id);
    this.movie = this.movService.getMoviebyId(this.id);
    console.log(this.movie);
  }

  

  onSave(){
    this.movService.updateMovie(this.movie);
     this.router.navigate(['/movies']);

  }

}
