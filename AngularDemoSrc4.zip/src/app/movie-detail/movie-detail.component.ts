import { Component, OnInit } from '@angular/core';
import { IMovie } from '../movies/movie.model';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MovieService } from '../movies/movie.service';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faCircleInfo } from '@fortawesome/free-solid-svg-icons';
import { faCirclePlay } from '@fortawesome/free-solid-svg-icons';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-movie-detail',
  imports: [RouterModule,CommonModule,FormsModule,FontAwesomeModule],
  templateUrl: './movie-detail.component.html',
  styleUrl: './movie-detail.component.css'
})
export class MovieDetailComponent implements OnInit{
  id:number|undefined;
  movie:IMovie|undefined;
  faCircleInfo = faCircleInfo;
  faCirclePlay = faCirclePlay


  //DI
  constructor(
    private router:Router,
    private aroute:ActivatedRoute,
    private movService:MovieService
  ){}
  
  ngOnInit():void{

    this.id = Number(this.aroute.snapshot.paramMap.get('id'));
    console.log(this.id);
    this.movie = this.movService.getMoviebyId(this.id);
    console.log(this.movie);
  }

  onBack(){
    this.router.navigate(['/movies']);
  }

  onEdit(){
  this.router.navigate(['/movies',this.id,'edit'])//localhost:400/movies/2/edit
  }
}
