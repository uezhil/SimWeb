import { Component, OnInit } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { RouterOutlet,RouterLink } from '@angular/router';
import { IMovie } from './movie.model';

@Component({
  selector: 'app-movies',
  imports: [FormsModule, CommonModule,RouterLink],
  templateUrl: './movies.component.html',
  styleUrl: './movies.component.css'
})
export class MoviesComponent implements OnInit{
  

  
  //props
  
  // movieID:number = 1001;
  // movieName:string = "Inception";
  // movieColl:number = 1000000;
  // movieImg="inception.jpg";
  _searchTerm:string = "";
  searchedMovies:IMovie[];
  imgHeight = 100;
  imgWidth = 200;
  imgBorder = 10;

  //Getter/Setter
  get searchTerm():string{
    return this._searchTerm;
  }
  set searchTerm(value:string){
      this._searchTerm = value;
      this.searchedMovies = this.searchTerm ?
      this.performSearch(this._searchTerm):this.movies;
  }
  constructor(){
    this.searchedMovies=this.movies;
    console.log("Here we will invoke DI for service");
}
  ngOnInit(): void {
  console.log("At the init phase now");
      }
movies:IMovie[] = [ {
    "movieID":1,
    "movieName":"Avengers - EndGame",
    "movieStar":"Robert Downey",
    "movieGenre":"Action",
    "movieRating":5.0,
    "movieImg":"images/avenger1.png"
},
{
"movieID":2,
"movieName":"Antman",
"movieStar":"Paul Rudd",
"movieGenre":"Action",
"movieRating":4,
"movieImg":"images/antman.jpg"
},
{
"movieID":3,
"movieName":"How to train - your Dragon",
"movieStar":"Hiccup - Thames",
"movieGenre":"Animated",
"movieRating":3,
"movieImg":"images/how-to-train-your-dragon-3.jpg"

},
{
"movieID":4,
"movieName":"Tangled",
"movieStar":"Mandy-moore",
"movieGenre":"SciFi",
"movieRating":4.5,
"movieImg":"images/tangled.jpg"

},
{
"movieID":5,
"movieName":"Moana",
"movieStar":"Dawyne",
"movieGenre":"Animated",
"movieRating":5,
"movieImg":"images/moana.jpg"

},
{
"movieID":6,
"movieName":"I-T",
"movieStar":"Pennywise",
"movieGenre":"Horror",
"movieRating":3.8,
"movieImg":"images/it.jpg"

},
{
"movieID":7,
"movieName":"Matrix",
"movieStar":"Keanu Reeves",
"movieGenre":"SciFi",
"movieRating":5,
"movieImg":"images/matrix.jpg"

},
{
"movieID":8,
"movieName":"Avatar - The Way of Water",
"movieStar":"Sam Worthington",
"movieGenre":"SciFi",
"movieRating":4,
"movieImg":"images/Avatar.jpg"

}
  ]
performSearch(searchby:string):IMovie[]{
  searchby=searchby.toLocaleLowerCase();
  return this.movies.filter((movie:IMovie)=>
  movie.movieName.toLocaleLowerCase().indexOf(searchby)!==-1);
  }

check():void{
  console.log("Searching for : "+ this.searchTerm );
  
}



}


