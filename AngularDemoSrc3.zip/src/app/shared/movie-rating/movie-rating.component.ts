import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faStar } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'movie-rating',
  imports: [FontAwesomeModule],
  templateUrl: './movie-rating.component.html',
  styleUrl: './movie-rating.component.css'
})
export class MovieRatingComponent {

  faStar =faStar;
  @Input() rating:number=0;
  starWidth:number=0;
  @Output() ratingClicked:EventEmitter<string> = 
  new EventEmitter<string>();

  ngOnChanges():void{
    this.starWidth= this.rating * 100/5;
    console.log("At on changes");
  }

  onClick():void{
        this.ratingClicked.emit(` rating is ${this.rating}`);

    }
  


}
