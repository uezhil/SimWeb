import { Injectable } from "@angular/core";
import { IMovie } from "./movie.model";

//1.Create the Service & 2.Register
//decorator
@Injectable({
    providedIn:'root'
})

export class MovieService{
    movies:IMovie[] = [ {
    "movieID":1,
    "movieName":"Avengers - EndGame from Service",
    "movieStar":"Robert Downey",
    "movieGenre":"Action",
    "movieRating":2.3,
    "movieImg":"images/avenger1.png"
},
{
"movieID":2,
"movieName":"Antman",
"movieStar":"Paul Rudd",
"movieGenre":"Action",
"movieRating":4,
"movieImg":"images/antman.jpg"
},
{
"movieID":3,
"movieName":"How to train - your Dragon",
"movieStar":"Hiccup - Thames",
"movieGenre":"Animated",
"movieRating":3,
"movieImg":"images/how-to-train-your-dragon-3.jpg"

},
{
"movieID":4,
"movieName":"Tangled",
"movieStar":"Mandy-moore",
"movieGenre":"SciFi",
"movieRating":4.5,
"movieImg":"images/tangled.jpg"

},
{
"movieID":5,
"movieName":"Moana",
"movieStar":"Dawyne",
"movieGenre":"Animated",
"movieRating":5,
"movieImg":"images/moana.jpg"

},
{
"movieID":6,
"movieName":"I-T",
"movieStar":"Pennywise",
"movieGenre":"Horror",
"movieRating":3.8,
"movieImg":"images/it.jpg"

},
{
"movieID":7,
"movieName":"Matrix",
"movieStar":"Keanu Reeves",
"movieGenre":"SciFi",
"movieRating":5,
"movieImg":"images/matrix.jpg"

},
{
"movieID":8,
"movieName":"Avatar - The Way of Water",
"movieStar":"Sam Worthington",
"movieGenre":"SciFi",
"movieRating":4,
"movieImg":"images/Avatar.jpg"

}
  ]

  getMovies(){
    return this.movies;
  }

}

